# common-settings.vim
Common/Reasonable Settings for Vim
